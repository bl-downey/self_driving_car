Rosbag FILE DESCRIPTIONS

figure8.bag -- SIMULATION figure 8 recording

figure8_* -- PHYSICAL figure 8 recordings (we used figure8_4.bag for our recordings)

base*.bag -- PHYSICAL basement track recordings. Since we ran into so many different 
	     problems with the phsyical robot we recorded a bunch of times trying 
	     slightly different things. All resulted in a relatively bad performance.
	     For our video we used basement3.bag. 
#!/usr/bin/env python

import rospy
import numpy as np
from geometry_msgs.msg import PoseStamped
import Utils # <----------- LOOK AT THESE FUNCTIONS ***************************

SUB_TOPIC = '/car/car_pose' # The topic that provides the simulated car pose
PUB_TOPIC = '/clone_follower_pose/pose' # The topic that you should publish to
MAP_TOPIC = '/static_map' # The service topic that will provide the map

# Follows the simulated robot around
class CloneFollower:

  '''
  Initializes a CloneFollower object
  In:
    follow_offset: The required x offset between the robot and its clone follower
    force_in_bounds: Whether the clone should toggle between following in front
                     and behind when it goes out of bounds of the map
  '''
  def __init__(self, follow_offset, force_in_bounds):
    # YOUR CODE HERE 
    self.follow_offset = follow_offset # Store the input params in self
    self.force_in_bounds = force_in_bounds # Store the input params in self
    self.map_img, self.map_info = Utils.get_map(MAP_TOPIC) # Get and store the map
                                  # for bounds checking
    
    # Setup publisher that publishes to PUB_TOPIC
    self.pub = rospy.Publisher(PUB_TOPIC, PoseStamped, queue_size = 10)
    
    # Setup subscriber that subscribes to SUB_TOPIC and uses the self.update_pose
    # callback
    self.sub = rospy.Subscriber(SUB_TOPIC, PoseStamped, self.update_pose)
    
  '''
  Given the translation and rotation between the robot and map, computes the pose
  of the clone
  (This function is optional)
  In:
    trans: The translation between the robot and map
    rot: The rotation between the robot and map
  Out:
    The pose of the clone
  '''
  def compute_follow_pose(self, trans, rot):
    # YOUR CODE HERE
    rospy.loginfo('trans %s', trans)
    rospy.loginfo('rot %s', rot)
  '''
  Callback that runs each time a sim pose is received. Should publish an updated
  pose of the clone.
  In:
    msg: The pose of the simulated car. Should be a geometry_msgs/PoseStamped
  '''  
  def update_pose(self, msg):
    # YOUR CODE HERE
    #use the angle from the utils function quaternion2angle to calculate pose for clone below
    angle_yaw = Utils.quaternion_to_angle(msg.pose.orientation)
    
    # Compute the pose of the clone
    # Note: To convert from a message quaternion to corresponding rotation matrix,
    #       look at the functions in Utils.py
    out_msg = PoseStamped() 
    out_msg.pose.position.x = msg.pose.position.x + (self.follow_offset * np.cos(angle_yaw))
    out_msg.pose.position.y = msg.pose.position.y + (self.follow_offset * np.sin(angle_yaw))

    # Check bounds if required
    if self.force_in_bounds:
      #pose = [, ,angle_yaw]
      #map_coord = Utils.world_to_map(pose,self.map_info)
      if (self.follow_offset > 0 and (out_msg.pose.position.x > 6.2 or out_msg.pose.position.x < -5.3 or out_msg.pose.position.y > 5.0 or out_msg.pose.position.y < -5.0)) or (self.follow_offset < 0 and (out_msg.pose.position.x > 6.5 or out_msg.pose.position.x < -5.8 or out_msg.pose.position.y > 6.0 or out_msg.pose.position.y < -5.0)):
         self.follow_offset *= -1
	 #recalculate the positions with inverted follow_offset value
         out_msg.pose.position.x = msg.pose.position.x + (self.follow_offset * np.cos(angle_yaw))
         out_msg.pose.position.y = msg.pose.position.y + (self.follow_offset * np.sin(angle_yaw))
      # Functions in Utils.py will again be useful here
      pass
      
    # Setup the out going PoseStamped message
    

    out_msg.header.seq = msg.header.seq
    out_msg.header.stamp = rospy.Time.now()
    out_msg.header.frame_id = "map"
    
    out_msg.pose.position.z = msg.pose.position.z 

    out_msg.pose.orientation.x = msg.pose.orientation.x
    out_msg.pose.orientation.y = msg.pose.orientation.y
    out_msg.pose.orientation.z = msg.pose.orientation.z
    out_msg.pose.orientation.w = msg.pose.orientation.w

    # Publish the clone's pose
    
    self.pub.publish(out_msg)

    
if __name__ == '__main__':
	#DEFAULT values for follow_offset and force_in_bounds
  follow_offset = 1.0 # The offset between the robot and clone
  force_in_bounds = False # Whether or not map bounds should be enforced
  
  rospy.init_node('clone_follower', anonymous=True) # Initialize the node
  
  # Populate params with values passed by launch file
  # Since they are not private vars, dont need '~' preceeding name
  follow_offset = rospy.get_param('follow_offset')
  force_in_bounds = rospy.get_param('force_in_bounds') 
  
  cf = CloneFollower(follow_offset, force_in_bounds) # Create a clone follower
  rospy.spin() # Spin
  

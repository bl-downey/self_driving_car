#!/usr/bin/env python

import time
import rospy
import rosbag
from ackermann_msgs.msg import AckermannDriveStamped
# Name of the topic that should be extracted from the bag
BAG_TOPIC = '/car/mux/ackermann_cmd_mux/input/teleop'
PUB_TOPIC = '/car/mux/ackermann_cmd_mux/input/teleop'
PUB_RATE = 65 # The rate at which messages should be published

# Loads a bag file, reads the msgs from the specified topic, and republishes them
def follow_bag(bag_path, follow_backwards=False):
   bag = rosbag.Bag(bag_path)
   rate = rospy.Rate(PUB_RATE)
   for topic, msg, t in bag.read_messages():
      if topic == PUB_TOPIC: 
         out_msg = AckermannDriveStamped()
         out_msg.header.seq = msg.header.seq 
         out_msg.header.stamp = rospy.Time.now()
         out_msg.header.frame_id = msg.header.frame_id
         out_msg.drive.steering_angle = msg.drive.steering_angle
         out_msg.drive.speed = msg.drive.speed
	 if follow_backwards == True:
            out_msg.drive.speed *= -1
	 rate.sleep() #needed for the code to actually work
         pub.publish(out_msg)

if __name__ == '__main__':
	bag_path = None # The file path to the bag file
	follow_backwards = False # Whether or not the path should be followed backwards
	
	rospy.init_node('bag_follower', anonymous=True)
	pub = rospy.Publisher(PUB_TOPIC, AckermannDriveStamped, queue_size = 10)	

	# Populate param(s) with value(s) passed by launch file
	bag_path = rospy.get_param('bag_path')
	follow_backwards = rospy.get_param('follow_backwards')

	follow_bag(bag_path, follow_backwards)
	#rospy.spin() # Spin



#!/usr/bin/env python

import cv2
import math
import numpy 
import Utils
import rospy
import matplotlib
import matplotlib.pyplot as plt

from nav_msgs.srv import GetMap

class ObstacleManager(object):

	def __init__(self, mapMsg, car_width, car_length, collision_delta):
		self.map_info = mapMsg.info
		self.mapImageGS = numpy.array(mapMsg.data, dtype=numpy.uint8).reshape(
			(mapMsg.info.height, mapMsg.info.width, 1))

		# Retrieve the map dimensions
		height, width, channels = self.mapImageGS.shape
		self.mapHeight = height
		self.mapWidth = width
		self.mapChannels = channels

		# Binarize the Image
		self.mapImageBW = 255 * numpy.ones_like(self.mapImageGS, dtype=numpy.uint8)
		self.mapImageBW[self.mapImageGS == 0] = 0

		# Obtain the car length and width in pixels
		self.robotWidth = int(1.5*car_width / self.map_info.resolution + 0.5)
		self.robotLength = int(1.5*car_length / self.map_info.resolution + 0.5)
		self.collision_delta = collision_delta


		badBoiPoints = [[1910, 340],[1500, 210],[1520, 435],[1130, 400],[670, 840]]
		radius = 15
		for bbp in badBoiPoints:
			#print("Inserting bad boi points...!")
			for x in range(bbp[0]-radius,bbp[0]+radius):
				for y in range(bbp[1]-radius,bbp[1]+radius):
#					print("hehe")
					self.mapImageBW[1235-y][x] = 255
		#for x in range(1550, 1610):
		#	for y in range(551, 670):
		#		self.mapImageBW[1235-y][x] = 0

		#print(self.mapImageBW.shape)
		#plt.figure()
		#plt.imshow(self.mapImageBW[:,:,0], cmap='gray')
		#plt.show()

		

	# Check if the passed config is in collision
	# config: The configuration to check (in meters and radians)
	# Returns False if in collision, True if not in collision
	def get_state_validity(self, config):

		# Convert the configuration to map-coordinates -> mapConfig is in pixel-space
		mapConfig = Utils.world_to_map(config, self.map_info)
		# ---------------------------------------------------------
		# Return true or false based on whether the robot's configuration is in collision
		# Use a square to represent the robot, return true only when all points within
		# the square are collision free
		#
		# Also return false if the robot is out of bounds of the map
		#
		# Although our configuration includes rotation, assume that the
		# square representing the robot is always aligned with the coordinate axes of the
		# map for simplicity
		# ----------------------------------------------------------
		if mapConfig[1] >= self.mapHeight or mapConfig[0] >= self.mapWidth: return False
		temp = mapConfig[0]
		mapConfig[0] = mapConfig[1]
		mapConfig[1] = temp # lolz, lmao
     	        if (self.mapImageBW[mapConfig[0]][mapConfig[1]] == 255): return False # return false if the robot is 												out of bounds
		upperLeft = [int(mapConfig[0] - self.robotLength/2),int(mapConfig[1] + self.robotWidth/2)]
		upperRight = [int(mapConfig[0] + self.robotLength/2),int(mapConfig[1] + self.robotWidth/2)]
		lowerLeft = [int(mapConfig[0] - self.robotLength/2),int(mapConfig[1] - self.robotWidth/2)]
		#print("checking robot config!")
		for x in range(upperLeft[0], upperRight[0] + 1, 1):
		   for y in range(lowerLeft[1], upperLeft[1] + 1, 1):
#			print("loooooop")
			if (self.mapImageBW[x][y] == 255): return False
		return True

	# Discretize the path into N configurations, where N = path_length / self.collision_delta
	#
	# input: an edge represented by the start and end configurations
	#
	# return three variables:
	# list_x - a list of x values of all intermediate points in the path
	# list_y - a list of y values of all intermediate points in the path
	# edgeLength - The euclidean distance between config1 and config2
	def discretize_edge(self, config1, config2):
		list_x, list_y = [], []
		edgeLength = numpy.sqrt((config1[0]-config2[0])**2+(config1[1]-config2[1])**2)

		N = math.ceil(edgeLength / self.collision_delta)

		list_x = numpy.linspace(config1[0], config2[0], N)
		list_y = numpy.linspace(config1[1], config2[1], N)

		return list_x, list_y, edgeLength


	# Check if there is an unobstructed edge between the passed configs
	# config1, config2: The configurations to check (in meters and radians)
	# Returns false if obstructed edge, True otherwise
	def get_edge_validity(self, config1, config2):
		# -----------------------------------------------------------
		# Check if endpoints are obstructed, if either is, return false
		# Find path between two configs by connecting them with a straight line
		# Discretize the path with the discretized_edge function above
		# Check if all configurations along path are obstructed
		# -----------------------------------------------------------
		if not self.get_state_validity(config1) or not self.get_state_validity(config2): return False
		x_list,y_list,euc = self.discretize_edge(config1, config2)
		
		for i in range(len(x_list)): 
		   config = [x_list[i], y_list[i]]
		   if not self.get_state_validity(config):
		      return False
		return True


# Write Your Test Code For Debugging
if __name__ == '__main__':
    rospy.init_node("obstacle_manager")
    map_service_name = rospy.get_param("~static_map", "static_map")
    print("Getting map from service: ", map_service_name)
    rospy.wait_for_service(map_service_name)

    map_msg = rospy.ServiceProxy(map_service_name, GetMap)().map
    car_length = 0.33
    car_width = 0.16
    collision_delta = 1

    om = ObstacleManager(map_msg, car_width, car_length, collision_delta)

    config1 = [-10,3]
    config2 = [-1,2]
    config3 = [-10,4]

    while True:
	print("1")
	print(om.get_edge_validity(config1, config2))
	print("2")
	print(om.get_edge_validity(config1, config3))
	print("3")
	print(om.get_edge_validity(config2, config3))
	break






#!/usr/bin/env python
import sys
import csv
import rospy 
import Utils as u
import numpy as np

sys.path.append("/home/robot/catkin_ws/src/finalRace/src/lineFollower")

from geometry_msgs.msg import PoseArray, PoseStamped, Pose
from ackermann_msgs.msg import AckermannDriveStamped

from line_follower import LineFollower

#global
inferred_pose = [0.0,0.0,0.0]
PUB_TOPIC = '/car/mux/ackermann_cmd_mux/input/navigation'

global mega_plan
		
def inferred_pose_cb(pose):
	global inferred_pose
	inferred_pose[0] = pose.pose.position.x
	inferred_pose[1] = pose.pose.position.y
	inferred_pose[2] = u.quaternion_to_angle(pose.pose.orientation)

def publish_plan(plan):
    pa = PoseArray()
    pa.header.frame_id = "/map"
    for i in xrange(len(plan)):
      config = plan[i]
      pose = Pose()
      pose.position.x = config[0]
      pose.position.y = config[1]
      pose.position.z = 0.0
      pose.orientation = u.angle_to_quaternion(config[2])
      pa.poses.append(pose)
    return pa 

if __name__ == '__main__':
	rospy.init_node("finalRace", anonymous=True) # Initialize the node
	
	mega_plan = []
	plan_loc = '/home/robot/catkin_ws/src/finalRace/src/plan.txt'

	with open(plan_loc, 'r') as f:
		reader = csv.reader(f)
	 	for plan in reader:
			temp_plan = []
			for p in plan:
				p = p.split(', ')
				p[:] = [float(p[0][1:]), float(p[1][:]), float(p[2][:len(p[2])-1])]
				temp_plan.append(p)
			mega_plan.append(temp_plan)

	pose_topic = '/pf/viz/inferred_pose' # Default val: '/car/pose'
	plan_lookahead = 5 # Starting val: 5
	translation_weight = 0.95 # Starting val: 1.0
	rotation_weight = 0.05 # Starting val: 0.0
	kp = -0.35 # Startinig val: 1.0
	ki = -0.03 #-0.052 # Starting val: 0.0
	kd = -0.723  #-0.713 # Starting val: 0.0
	error_buff_length = 18 # Starting val: 10
	speed = 1.0 # Default val: 1.0

	plan_topic = '/planner_node/car_plan' # Default val: '/planner_node/car_plan'

	plan_pub = rospy.Publisher(plan_topic, PoseArray, queue_size=1)
	pf_pose_sub = rospy.Subscriber("/pf/viz/inferred_pose", PoseStamped, inferred_pose_cb)
	cmd_pub = rospy.Publisher(PUB_TOPIC, AckermannDriveStamped, queue_size = 10)

	raw_input("[Final Race] Press Enter to win the race...")  # Waits for ENTER key press
	
	print("[Final Race] length of mega-plan: ", len(mega_plan))

	for i in range(len(mega_plan)):
		print("[Final Race] Executing Plan segment: ", i+1)
		print(mega_plan[i])
		plan_pub.publish(publish_plan(mega_plan[i]))
		if i == 0: speed = -0.99
		else: speed = 0.99
                if i == 2: speed = 0.99
                if not i == 0:
		    lf = LineFollower(mega_plan[i], pose_topic, plan_lookahead, translation_weight, rotation_weight, kp, ki, kd, error_buff_length, speed, i)
		    while not lf.completed:
			rospy.sleep(0.3)
		    del lf
		if i == 0:

			print("[Final Race] Performing adjustment...")
			while inferred_pose[0] < 52.1:
				ads = AckermannDriveStamped()
    				ads.header.frame_id = '/map'
				ads.header.stamp = rospy.Time.now()
				ads.drive.steering_angle = 0.0
				ads.drive.speed = -0.8
				cmd_pub.publish(ads)
			print("[Final Race] ...adjustment completed")
                if i == 2: 
                        print("[Final Race] Performing Adjustment")
                        while inferred_pose[2] < 2.2 or inferred_pose[2] > 2.6:
                            ads = AckermannDriveStamped()
                            ads.header.frame_id = '/map'
                            ads.header.stamp = rospy.Time.now()
                            ads.drive.steering_angle = 0.34
                            ads.drive.speed = -0.99
                            cmd_pub.publish(ads)
                        print("[Final Race] ...adjustment completed")


	print("[Final Race] Bro.... did that just work? or am I tripping again...")
	rospy.spin() #dont kill






